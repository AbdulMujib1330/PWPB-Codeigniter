<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class auth extends CI_Controller {
	public function signin()
	{
		$this->load->view('sign');
	}

	public function login()
	{
		$this->load->view('login');
	}

	public function home()
	{
		$this->load->view('homepage');
	}

}
