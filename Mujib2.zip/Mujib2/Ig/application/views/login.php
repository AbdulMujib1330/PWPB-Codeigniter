<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <a href="">Submit</a>
</body>
</html> --><?php

// session_start();
// if(!isset($_SESSION["nama_resepsionis"])) { 
//    header("Location:proses_login_resepsionis.php");
// }
?>
<!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -->
<!DOCTYPE html>
<html lang="en">
<head>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
<title>Login</title>
</head>
<!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -->
<body>
<!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -->
<form action="../proses/login.php" method="post">
<section class="vh-100 gradient-custom">
<div class="container py-5 h-100">
  <div class="row d-flex justify-content-center align-items-center h-100">
    <div class="col-12 col-md-8 col-lg-6 col-xl-5">
      <div class="card bg-dark text-white" style="border-radius: 1rem;">
        <div class="card-body p-5 py-2 text-center">

          <div class="mb-md-5 mt-md-4 pb-5">

            <h2 class="fw-bold mb-2 text-uppercase">Login</h2>
            <p class="text-white-50 mb-5">Please enter your login and password!</p>

            <div class="form-outline form-white mb-4">
              <input type="email" name="Email" id="typeEmailX" class="form-control form-control-lg" />
              <label class="form-label" for="typeEmailX">Email</label>
            </div>

            <div class="form-outline form-white mb-4">
              <input type="password" name="Password" id="typePasswordX" class="form-control form-control-lg" />
              <label class="form-label" for="typePasswordX">Password</label>
            </div>


            <button class="btn btn-outline-light btn-lg px-5" type="submit">Login</button>

          </div>

          <div>
            <p class="mb-0">Don't have an account? <a href="sign" class="text-white-50 fw-bold">Sign-Up <a class="text-light">/</a><a onclick="return confirm('Ingin Keluar?')"  href="homepage" class=""> Home</a></a>
            </p>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>
</section>
<!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -->
</body>
</html>





  <!-- <div class="container">
      <div class="row">
      <div class="col-md-6 offset-md-3">
      <marquee behavior="" direction=""><h1>---------------Login---------------</h></marquee>
          <div class="card my-5">
              <div class="card text-center">
                  <h6 class="pb-5 positioning">Login Your Account</h6>    
              </div>
              <form class="card-body cardbody-color p-lg-5">
                  <div class="mb-3 w-50">
                      <input type="text" class="form-control" name="nama" placeholder="nama">
                  </div>
                  <div class="mb-3 w-50">
                      <input type="password" class="form-control" name="password" placeholder="password">
                  </div>
                  <div class="text-center">
                      <button type="submit" class="btn btn-light btn-outline-primary px-5 mb-2 w-150">Login</button>
                  <br>
                      <a href="sign.php" class="text-center mb-2">Sign</a>
                  </div>
              </form>
          </div>
      </div>
      </div>
  </div>
</form>
</body>
</html> -->